package org.jordi.btlealumnos2021;

import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class Server {

    private static final String Url1 = "http://192.168.43.76/proyecto_3a/src/api/saveprueba.php";

    public static void crearPrueba(final String co2bd, final String tempbd , RequestQueue requestQueue) {
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                Url1,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("Pelochas", error.toString());
                    }
                }

        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map <String, String> params = new HashMap<>();
                params.put("co2",co2bd);
                params.put("temp",tempbd);
                return params;

            }
        };
        requestQueue.add(stringRequest);
    }

    public static String getUrl1()
    {
        return  Url1;
    }
}
